

class UserAttr{
  String id;
  String mobileNumber;
  String name;
  String email;
  String joinedDate;
  String status;

  UserAttr({required this.id,required this.mobileNumber,required this.name,required this.email,required this.joinedDate,required this.status});
}