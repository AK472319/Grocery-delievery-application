class Slider {
  String image1;
  String image2;
  String image3;
  String image4;

  Slider({
    required this.image1,
    required this.image2,
    required this.image3,
    required this.image4,
  });
}
