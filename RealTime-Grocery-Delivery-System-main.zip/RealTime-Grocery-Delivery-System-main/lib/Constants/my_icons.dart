import 'package:flutter/material.dart';

class MyAppIcon{
  static IconData home=Icons.home;
  static IconData feeds=Icons.rss_feed;
  static IconData search=Icons.search;
  static IconData cart=Icons.shopping_bag;
  static IconData user=Icons.person;
}